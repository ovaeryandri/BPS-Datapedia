<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
{
    Schema::table('konsultans', function (Blueprint $table) {
        $table->string('gambar')->after('nama');
        $table->string('posisi')->after('gambar');
        $table->string('keahlian')->after('posisi');
    });
}

public function down(): void
{
    Schema::table('konsultans', function (Blueprint $table) {
        $table->dropColumn(['gambar', 'posisi', 'keahlian']);
    });
}

};
